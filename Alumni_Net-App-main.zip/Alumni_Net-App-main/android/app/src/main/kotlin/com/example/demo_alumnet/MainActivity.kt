package com.example.demo_alumnet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
